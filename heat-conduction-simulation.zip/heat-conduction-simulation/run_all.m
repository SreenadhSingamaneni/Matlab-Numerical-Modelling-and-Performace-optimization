% run_all.m
% =========================================================================
% Master runner: executes all heat-conduction-simulation scripts in order.
%
% Usage (from repo root in MATLAB):
%   run('run_all.m')
%   OR simply open MATLAB, cd to the repo root, and press Run.
%
% What it runs:
%   1. simulate_heat_1d   - main simulation (Euler vs RK4 vs exact)
%   2. stability_analysis - dt sweep, blow-up detection, Euler vs RK4
%   3. error_convergence  - temporal + spatial convergence rates
%   4. profiler_benchmark - loop vs vectorized RHS timing
%
% All plots and logs are saved to results/
% =========================================================================

fprintf('\n%s\n', repmat('=', 1, 60));
fprintf('  heat-conduction-simulation  |  run_all.m\n');
fprintf('%s\n\n', repmat('=', 1, 60));

% ---- Add src/ to path ----------------------------------------------------
src_path = fullfile(fileparts(mfilename('fullpath')), 'src');
addpath(src_path);

% ---- Ensure results/ directory exists ------------------------------------
results_path = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(results_path, 'dir')
    mkdir(results_path);
end

% ---- Run all modules with error isolation --------------------------------
modules = {'simulate_heat_1d', 'stability_analysis', ...
           'error_convergence', 'profiler_benchmark'};

pass = true(1, numel(modules));

for m = 1:numel(modules)
    name = modules{m};
    fprintf('\n%s\n', repmat('-', 1, 60));
    fprintf('  Running: %s\n', name);
    fprintf('%s\n', repmat('-', 1, 60));
    try
        feval(name);
    catch ME
        fprintf('\n[ERROR] %s failed:\n  %s\n', name, ME.message);
        pass(m) = false;
    end
end

% ---- Summary -------------------------------------------------------------
fprintf('\n%s\n', repmat('=', 1, 60));
fprintf('  run_all.m  SUMMARY\n');
fprintf('%s\n', repmat('=', 1, 60));
for m = 1:numel(modules)
    status = 'PASS';
    if ~pass(m), status = 'FAIL'; end
    fprintf('  [%s]  %s\n', status, modules{m});
end
fprintf('\nAll results saved to: %s\n\n', results_path);
