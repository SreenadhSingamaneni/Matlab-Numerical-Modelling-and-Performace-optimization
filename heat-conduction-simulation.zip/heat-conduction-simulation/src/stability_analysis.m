function stability_analysis()
%STABILITY_ANALYSIS Sweep dt values to study stability of Euler and RK4.
%
%   stability_analysis()
%
% This script:
%   - Sweeps a range of dt values around the Euler CFL stability limit
%   - Runs both Forward Euler and RK4 for each dt
%   - Detects blow-up (instability) via norm check
%   - Compares L2 error vs exact solution at final time
%   - Saves a log-log stability sweep plot to results/
%
% Key insight: both Euler and RK4 are conditionally stable for diffusion.
%              RK4's stability region is ~1.39x larger than Euler's (not "much larger").
%              RK4's primary advantage is accuracy: O(dt^4) vs O(dt^1).

    % ---- Ensure paths and output directory --------------------------------
    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here));
    results_dir = fullfile(here, '..', 'results');
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end

    % ---- Parameters -------------------------------------------------------
    L     = 1;
    alpha = 1;
    Nx    = 80;
    dx    = L / (Nx + 1);
    T     = 0.1;

    x_all      = linspace(0, L, Nx + 2);
    x_interior = x_all(2:end-1);

    A  = build_laplacian(Nx, dx, alpha);
    U0 = sin(pi * x_interior / L)';

    % ---- Stability guideline for explicit Euler (diffusion) ---------------
    dt_cfl = dx^2 / (2 * alpha);
    fprintf('\n=== stability_analysis ===\n');
    fprintf('Nx=%d, dx=%.4f, CFL dt_max = %.4e\n', Nx, dx, dt_cfl);

    % ---- dt sweep: below, at, and above CFL limit -------------------------
    dt_factors = [0.05, 0.25, 0.5, 0.8, 1.0, 1.5, 2.0, 4.0];
    dt_values  = dt_cfl * dt_factors;

    N_dt          = numel(dt_values);
    euler_err     = nan(1, N_dt);
    rk4_err       = nan(1, N_dt);
    euler_stable  = false(1, N_dt);
    rk4_stable    = false(1, N_dt);

    BLOWUP_THRESH = 1e6;

    for k = 1:N_dt
        dt = dt_values(k);
        Nt = round(T / dt);
        dt_actual = T / Nt;   % exact final time

        % --- Euler ---
        U = U0;
        blew = false;
        for n = 1:Nt
            U = U + dt_actual * (A * U);
            if ~all(isfinite(U)) || norm(U, inf) > BLOWUP_THRESH
                blew = true; break;
            end
        end
        if ~blew
            euler_stable(k) = true;
            U_ex = exact_solution(x_interior, T, L, alpha)';
            euler_err(k) = norm(U - U_ex, 2) / sqrt(Nx);
        end

        % --- RK4 ---
        U = U0;
        blew = false;
        for n = 1:Nt
            k1 = A * U;
            k2 = A * (U + 0.5*dt_actual*k1);
            k3 = A * (U + 0.5*dt_actual*k2);
            k4 = A * (U +     dt_actual*k3);
            U  = U + (dt_actual/6) * (k1 + 2*k2 + 2*k3 + k4);
            if ~all(isfinite(U)) || norm(U, inf) > BLOWUP_THRESH
                blew = true; break;
            end
        end
        if ~blew
            rk4_stable(k) = true;
            U_ex = exact_solution(x_interior, T, L, alpha)';
            rk4_err(k) = norm(U - U_ex, 2) / sqrt(Nx);
        end

        fprintf('  dt=%.3e (x%.2f CFL) | Euler: %s | RK4: %s\n', ...
            dt, dt_factors(k), ...
            status_str(euler_stable(k), euler_err(k)), ...
            status_str(rk4_stable(k),  rk4_err(k)));
    end

    % ---- Plot -------------------------------------------------------------
    ts  = utils_timestamp();
    fig = figure('Name', 'Stability Sweep: Euler vs RK4', 'Visible', 'off');

    if any(euler_stable)
        loglog(dt_values(euler_stable), euler_err(euler_stable), ...
               '-ro', 'LineWidth', 2, 'MarkerSize', 7, 'DisplayName', 'Euler (stable)');
        hold on;
    end
    if any(~euler_stable)
        loglog(dt_values(~euler_stable), BLOWUP_THRESH * ones(1, sum(~euler_stable)), ...
               'rx', 'MarkerSize', 12, 'LineWidth', 2, 'DisplayName', 'Euler (blew up)');
        hold on;
    end
    if any(rk4_stable)
        loglog(dt_values(rk4_stable), rk4_err(rk4_stable), ...
               '-bs', 'LineWidth', 2, 'MarkerSize', 7, 'DisplayName', 'RK4 (stable)');
        hold on;
    end
    if any(~rk4_stable)
        loglog(dt_values(~rk4_stable), BLOWUP_THRESH * ones(1, sum(~rk4_stable)), ...
               'bx', 'MarkerSize', 12, 'LineWidth', 2, 'DisplayName', 'RK4 (blew up)');
        hold on;
    end

    % Mark CFL limit
    xline(dt_cfl, '--k', 'LineWidth', 1.5, 'DisplayName', sprintf('CFL limit (%.2e)', dt_cfl));

    hold off; grid on;
    xlabel('\Deltat');
    ylabel('Normalised L2 Error at T');
    legend('Location', 'best');
    title(sprintf('Stability Sweep: Euler vs RK4  (Nx=%d, T=%.2f)', Nx, T));

    out = fullfile(results_dir, ['stability_sweep_' ts '.png']);
    saveas(fig, out);
    close(fig);
    fprintf('Saved plot: %s\n', out);
end

% ---- Helper ---------------------------------------------------------------
function s = status_str(stable, err)
    if stable
        s = sprintf('stable  L2=%.2e', err);
    else
        s = 'UNSTABLE';
    end
end
