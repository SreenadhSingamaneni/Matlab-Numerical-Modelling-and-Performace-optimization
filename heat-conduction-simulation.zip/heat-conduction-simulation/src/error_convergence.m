function error_convergence()
%ERROR_CONVERGENCE Benchmark time-step AND spatial convergence for Euler vs RK4.
%
%   error_convergence()
%
% This script runs two independent convergence studies:
%
%  PART 1 - Temporal convergence (fixed fine Nx=200, separate dt sweeps):
%    - Euler sweep: dt relative to Euler CFL limit  -> expected slope O(dt^1)
%    - RK4   sweep: dt relative to RK4  stability limit -> expected slope O(dt^4)
%    - Using separate sweeps ensures both methods operate in their respective
%      temporal-error-dominated regimes.
%    - Note: for diffusion, RK4's stability region is only ~1.39x larger than
%      Euler's (not "much larger"); both are conditionally stable.
%
%  PART 2 - Spatial convergence (fixed tiny dt, sweep Nx):
%    - Fixes dt=1e-5 (temporal error negligible for all grid sizes used)
%    - Sweeps Nx = [10, 20, 40, 80, 160]
%    - Expected: both methods ~ O(dx^2)  (centered finite differences)
%
%  All plots saved to results/.

    % ---- Ensure paths and output directory --------------------------------
    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here));
    results_dir = fullfile(here, '..', 'results');
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end

    L     = 1;
    alpha = 1;
    T     = 0.1;

    % ======================================================================
    % PART 1: Temporal convergence
    % Nx=200 gives a fine enough grid that the spatial error floor is well
    % below the temporal errors across the entire dt sweep for both methods.
    % ======================================================================
    fprintf('\n=== error_convergence: Part 1 - Temporal ===\n');

    Nx_t  = 200;
    dx_t  = L / (Nx_t + 1);
    x_int = linspace(0, L, Nx_t + 2);
    x_int = x_int(2:end-1);

    A_t  = build_laplacian(Nx_t, dx_t, alpha);
    U0_t = sin(pi * x_int / L)';

    % Exact spectral radius of the Laplacian
    lam_max  = 2*alpha/dx_t^2 * (1 - cos(pi*Nx_t/(Nx_t+1)));
    dt_euler_lim = 2.0   / lam_max;   % Euler stability limit
    dt_rk4_lim   = 2.785 / lam_max;   % RK4   stability limit (~1.39x Euler)

    fprintf('  Nx=%d, dx=%.5f\n', Nx_t, dx_t);
    fprintf('  Euler stability limit: %.3e\n', dt_euler_lim);
    fprintf('  RK4   stability limit: %.3e  (%.2fx Euler)\n', dt_rk4_lim, dt_rk4_lim/dt_euler_lim);

    % ---- Euler dt sweep ---------------------------------------------------
    euler_dt_vals = dt_euler_lim * [0.80, 0.40, 0.20, 0.10, 0.05];
    euler_err_t   = zeros(1, numel(euler_dt_vals));

    fprintf('\n  Euler sweep:\n');
    for k = 1:numel(euler_dt_vals)
        dt = euler_dt_vals(k);
        [Ue, ~] = euler_solver(A_t, U0_t, dt, T);
        Uex = exact_solution(x_int, T, L, alpha)';
        euler_err_t(k) = norm(Ue - Uex, 2) / sqrt(Nx_t);
        fprintf('    dt=%.3e | L2=%.3e\n', dt, euler_err_t(k));
    end

    % ---- RK4 dt sweep (relative to RK4 limit) ----------------------------
    rk4_dt_vals = dt_rk4_lim * [0.80, 0.40, 0.20, 0.10, 0.05];
    rk4_err_t   = zeros(1, numel(rk4_dt_vals));

    fprintf('\n  RK4 sweep:\n');
    for k = 1:numel(rk4_dt_vals)
        dt = rk4_dt_vals(k);
        [Ur, ~] = rk4_solver(A_t, U0_t, dt, T);
        Uex = exact_solution(x_int, T, L, alpha)';
        rk4_err_t(k) = norm(Ur - Uex, 2) / sqrt(Nx_t);
        fprintf('    dt=%.3e | L2=%.3e\n', dt, rk4_err_t(k));
    end

    pE_t = polyfit(log(euler_dt_vals), log(euler_err_t), 1);
    pR_t = polyfit(log(rk4_dt_vals),   log(rk4_err_t),   1);
    fprintf('\n  Temporal convergence rate -> Euler: %.2f   RK4: %.2f\n', pE_t(1), pR_t(1));
    fprintf('  (Expected: Euler ~ 1.0,  RK4 ~ 4.0)\n');

    % ======================================================================
    % PART 2: Spatial convergence
    % ======================================================================
    fprintf('\n=== error_convergence: Part 2 - Spatial ===\n');

    dt_fine = 1e-5;
    Nx_vals = [10, 20, 40, 80, 160];
    dx_vals = L ./ (Nx_vals + 1);

    euler_err_x = zeros(1, numel(Nx_vals));
    rk4_err_x   = zeros(1, numel(Nx_vals));

    for k = 1:numel(Nx_vals)
        Nx  = Nx_vals(k);
        dx  = dx_vals(k);
        x_i = linspace(0, L, Nx + 2);
        x_i = x_i(2:end-1);

        A_k  = build_laplacian(Nx, dx, alpha);
        U0_k = sin(pi * x_i / L)';

        [Ue, ~] = euler_solver(A_k, U0_k, dt_fine, T);
        [Ur, ~] = rk4_solver (A_k, U0_k, dt_fine, T);

        Uex = exact_solution(x_i, T, L, alpha)';

        euler_err_x(k) = norm(Ue - Uex, 2) / sqrt(Nx);
        rk4_err_x(k)   = norm(Ur - Uex, 2) / sqrt(Nx);

        fprintf('  Nx=%3d  dx=%.4f | Euler L2=%.3e | RK4 L2=%.3e\n', ...
                Nx, dx, euler_err_x(k), rk4_err_x(k));
    end

    pE_x = polyfit(log(dx_vals), log(euler_err_x), 1);
    pR_x = polyfit(log(dx_vals), log(rk4_err_x),   1);
    fprintf('\n  Spatial convergence rate  -> Euler: %.2f   RK4: %.2f\n', pE_x(1), pR_x(1));
    fprintf('  (Expected: both ~ 2.0  from O(dx^2) centered differences)\n');

    % ======================================================================
    % Plots
    % ======================================================================
    ts = utils_timestamp();

    % --- Temporal convergence plot -----------------------------------------
    fig1 = figure('Name', 'Temporal Convergence: Euler vs RK4', 'Visible', 'off');

    loglog(euler_dt_vals, euler_err_t, '-ro', 'LineWidth', 2, 'MarkerSize', 7, ...
           'DisplayName', sprintf('Euler (slope=%.2f)', pE_t(1))); hold on;
    loglog(rk4_dt_vals,   rk4_err_t,   '-bs', 'LineWidth', 2, 'MarkerSize', 7, ...
           'DisplayName', sprintf('RK4   (slope=%.2f)', pR_t(1)));

    % Reference lines
    all_dt = sort([euler_dt_vals, rk4_dt_vals]);
    c1 = euler_err_t(1) / euler_dt_vals(1)^1;
    c4 = rk4_err_t(1)   / rk4_dt_vals(1)^4;
    loglog(all_dt, c1*all_dt.^1, '--k',  'LineWidth', 1.0, 'DisplayName', 'O(\Deltat^1)');
    loglog(all_dt, c4*all_dt.^4, ':k',   'LineWidth', 1.0, 'DisplayName', 'O(\Deltat^4)');

    hold off; grid on;
    xlabel('\Deltat'); ylabel('Normalised L2 Error at T');
    legend('Location', 'best');
    title(sprintf('Temporal Convergence  (Nx=%d, T=%.2f) — separate dt sweeps per method', Nx_t, T));

    out1 = fullfile(results_dir, ['convergence_temporal_' ts '.png']);
    saveas(fig1, out1); close(fig1);
    fprintf('\nSaved plot: %s\n', out1);

    % --- Spatial convergence plot ------------------------------------------
    fig2 = figure('Name', 'Spatial Convergence: Euler vs RK4', 'Visible', 'off');

    loglog(dx_vals, euler_err_x, '-ro', 'LineWidth', 2, 'MarkerSize', 7, ...
           'DisplayName', sprintf('Euler (slope=%.2f)', pE_x(1))); hold on;
    loglog(dx_vals, rk4_err_x,   '-bs', 'LineWidth', 2, 'MarkerSize', 7, ...
           'DisplayName', sprintf('RK4   (slope=%.2f)', pR_x(1)));

    c2 = euler_err_x(1) / dx_vals(1)^2;
    loglog(dx_vals, c2*dx_vals.^2, '--k', 'LineWidth', 1.0, 'DisplayName', 'O(\Deltax^2)');

    hold off; grid on;
    xlabel('\Deltax'); ylabel('Normalised L2 Error at T');
    legend('Location', 'best');
    title(sprintf('Spatial Convergence  (dt=%.0e, T=%.2f)', dt_fine, T));

    out2 = fullfile(results_dir, ['convergence_spatial_' ts '.png']);
    saveas(fig2, out2); close(fig2);
    fprintf('Saved plot: %s\n', out2);
end
