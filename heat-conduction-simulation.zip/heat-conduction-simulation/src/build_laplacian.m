function A = build_laplacian(Nx, dx, alpha)
%BUILD_LAPLACIAN Build the tridiagonal 1D Laplacian matrix (Dirichlet BCs).
%
%   A = build_laplacian(Nx, dx, alpha)
%
% Inputs:
%   Nx    : number of interior spatial grid points
%   dx    : spatial grid spacing
%   alpha : thermal diffusivity
%
% Output:
%   A     : Nx x Nx sparse tridiagonal matrix for dU/dt = A * U
%
% The semi-discrete ODE system is:
%   dU/dt = A * U
% where U is the vector of temperatures at interior points.

    e = ones(Nx, 1);
    A = (alpha / dx^2) * spdiags([e, -2*e, e], [-1, 0, 1], Nx, Nx);
end
