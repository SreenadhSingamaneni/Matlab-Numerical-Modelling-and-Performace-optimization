function [U, tvec] = euler_solver(A, U0, dt, T)
%EULER_SOLVER Forward Euler time integration for dU/dt = A*U
%
%   [U, tvec] = euler_solver(A, U0, dt, T)
%
% Inputs:
%   A   : spatial operator matrix (Nx x Nx)
%   U0  : initial interior temperature vector (Nx x 1)
%   dt  : time step (must satisfy CFL: dt <= dx^2 / (2*alpha))
%   T   : final simulation time
%
% Outputs:
%   U    : solution vector at final time T (Nx x 1)
%   tvec : time vector (1 x Nt+1)
%
% Forward Euler scheme (1st-order accurate in time):
%   U_{n+1} = U_n + dt * A * U_n
%
% Stability condition for diffusion: dt <= dx^2 / (2*alpha)
% Violating this leads to exponential blow-up.

    Nt   = round(T / dt);   % use round instead of floor to avoid drift
    dt   = T / Nt;          % adjust dt slightly so Nt*dt = T exactly
    U    = U0;
    tvec = linspace(0, T, Nt + 1);

    for n = 1:Nt
        U = U + dt * (A * U);
    end
end
