function U_exact = exact_solution(x_interior, t, L, alpha)
%EXACT_SOLUTION Closed-form analytical solution for the 1D heat equation.
%
%   U_exact = exact_solution(x_interior, t, L, alpha)
%
% Problem: u_t = alpha * u_xx on (0,L)
%          u(0,t) = u(L,t) = 0  (Dirichlet BCs)
%          u(x,0) = sin(pi*x/L) (initial condition)
%
% Exact solution:
%   u(x,t) = exp(-alpha*(pi/L)^2*t) * sin(pi*x/L)
%
% Inputs:
%   x_interior : row or column vector of interior spatial points
%   t          : scalar time value
%   L          : domain length
%   alpha      : thermal diffusivity
%
% Output:
%   U_exact : vector of exact temperatures at x_interior, time t

    U_exact = exp(-alpha * (pi/L)^2 * t) .* sin(pi * x_interior / L);
end
