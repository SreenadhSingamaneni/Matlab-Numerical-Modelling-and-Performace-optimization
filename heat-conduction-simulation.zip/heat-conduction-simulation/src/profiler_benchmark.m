function profiler_benchmark()
%PROFILER_BENCHMARK Compare loop-based vs vectorized RHS evaluation.
%
%   profiler_benchmark()
%
% This script:
%   - Builds a large representative state vector U (Nx=2000)
%   - Computes dU/dt using two methods:
%       (1) Loop-based stencil  (naive, O(Nx) loop in MATLAB)
%       (2) Sparse matrix-vector multiply  A*U  (vectorized)
%   - Verifies both give identical results (assertion)
%   - Times both with timeit() for reliable measurement
%   - Computes and reports the speedup
%   - Writes a benchmark log to results/benchmark_*.txt
%
% Typical result: vectorized is 10-100x faster for large Nx.

    % ---- Ensure paths and output directory --------------------------------
    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here));
    results_dir = fullfile(here, '..', 'results');
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end

    % ---- Setup ------------------------------------------------------------
    L = 1; alpha = 1; Nx = 2000;
    dx = L / (Nx + 1);
    x_interior = linspace(0, L, Nx + 2);
    x_interior = x_interior(2:end-1);

    A = build_laplacian(Nx, dx, alpha);    % sparse matrix
    U = sin(pi * x_interior / L)';

    % ---- Correctness check ------------------------------------------------
    dU_loop = loop_rhs(U, dx, alpha);
    dU_vec  = A * U;
    tol = 1e-10;
    assert(norm(dU_loop - dU_vec, inf) < tol, ...
           'Mismatch between loop RHS and vectorized RHS!');

    % ---- Timing -----------------------------------------------------------
    t_loop = timeit(@()  loop_rhs(U, dx, alpha));
    t_vec  = timeit(@() (A * U));
    speedup = t_loop / t_vec;

    % ---- Report -----------------------------------------------------------
    fprintf('\n=== profiler_benchmark (Nx=%d) ===\n', Nx);
    fprintf('  Loop RHS      : %.6f sec\n', t_loop);
    fprintf('  Vectorized RHS: %.6f sec\n', t_vec);
    fprintf('  Speedup       : %.1fx\n',    speedup);

    msg = sprintf(['Benchmark (Nx=%d)\n' ...
                   'Loop RHS      : %.6f sec\n' ...
                   'Vectorized RHS: %.6f sec\n' ...
                   'Speedup       : %.1fx\n'], ...
                   Nx, t_loop, t_vec, speedup);

    ts  = utils_timestamp();
    out = fullfile(results_dir, ['benchmark_' ts '.txt']);
    fid = fopen(out, 'w');
    fprintf(fid, '%s', msg);
    fclose(fid);
    fprintf('Wrote log: %s\n', out);
end

% ---- Local helper: loop-based stencil ------------------------------------
function dU = loop_rhs(U, dx, alpha)
%LOOP_RHS Loop-based second-derivative finite difference (Dirichlet BCs at 0 and L).
%
% Boundary values are implicitly zero (Dirichlet), so u_{0} = u_{Nx+1} = 0.

    Nx = numel(U);
    dU = zeros(Nx, 1);

    for i = 1:Nx
        u_left  = 0;
        u_right = 0;
        if i > 1,  u_left  = U(i-1); end
        if i < Nx, u_right = U(i+1); end
        dU(i) = alpha * (u_right - 2*U(i) + u_left) / dx^2;
    end
end
