function [U, tvec] = rk4_solver(A, U0, dt, T)
%RK4_SOLVER Classical 4th-order Runge-Kutta time integration for dU/dt = A*U
%
%   [U, tvec] = rk4_solver(A, U0, dt, T)
%
% Inputs:
%   A   : spatial operator matrix (Nx x Nx)
%   U0  : initial interior temperature vector (Nx x 1)
%   dt  : time step
%   T   : final simulation time
%
% Outputs:
%   U    : solution vector at final time T (Nx x 1)
%   tvec : time vector (1 x Nt+1)
%
% Classical RK4 scheme (4th-order accurate in time):
%   k1 = A * U_n
%   k2 = A * (U_n + dt/2 * k1)
%   k3 = A * (U_n + dt/2 * k2)
%   k4 = A * (U_n + dt   * k3)
%   U_{n+1} = U_n + (dt/6) * (k1 + 2*k2 + 2*k3 + k4)
%
% For diffusion problems, RK4's stability region is ~1.39x larger than Euler's
% (both are conditionally stable). RK4's main advantage is accuracy (O(dt^4) vs O(dt^1)),
% not stability.

    Nt   = round(T / dt);   % use round to avoid final-time drift
    dt   = T / Nt;          % adjust dt so Nt*dt = T exactly
    U    = U0;
    tvec = linspace(0, T, Nt + 1);

    for n = 1:Nt
        k1 = A * U;
        k2 = A * (U + 0.5*dt*k1);
        k3 = A * (U + 0.5*dt*k2);
        k4 = A * (U +     dt*k3);

        U = U + (dt/6) * (k1 + 2*k2 + 2*k3 + k4);
    end
end
