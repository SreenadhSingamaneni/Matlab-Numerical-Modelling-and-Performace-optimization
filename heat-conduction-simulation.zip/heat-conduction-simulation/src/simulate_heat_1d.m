function simulate_heat_1d()
%SIMULATE_HEAT_1D Main entry point: simulate 1D heat equation using Euler & RK4.
%
%   simulate_heat_1d()
%
% Solves: u_t = alpha * u_xx on (0, L) x (0, T]
%         u(0,t) = u(L,t) = 0   (Dirichlet BCs)
%         u(x,0) = sin(pi*x/L)  (initial condition)
%
% This script:
%   1) Builds spatial grid and sparse Laplacian matrix
%   2) Runs Forward Euler and RK4 solvers
%   3) Compares both against the analytical exact solution
%   4) Prints L2 and L-inf errors
%   5) Saves a comparison plot to results/
%
% Usage:
%   From the repo root:
%       addpath('src');
%       simulate_heat_1d;
%
% Parameters (edit below):
%   L     = domain length
%   alpha = thermal diffusivity
%   Nx    = number of interior spatial points
%   T     = final time
%   dt    = time step (must satisfy dt <= dx^2/(2*alpha) for Euler stability)

    % ---- Ensure paths and output directory --------------------------------
    here = fileparts(mfilename('fullpath'));
    addpath(fullfile(here));              % src/ is already on path via run_all
    results_dir = fullfile(here, '..', 'results');
    if ~exist(results_dir, 'dir')
        mkdir(results_dir);
    end

    % ---- Parameters -------------------------------------------------------
    L     = 1;
    alpha = 1;
    Nx    = 50;             % interior grid points
    dx    = L / (Nx + 1);
    T     = 0.1;
    dt    = 1e-4;           % stable for Euler at Nx=50 (CFL limit = dx^2/2alpha ~ 1.92e-4)

    % ---- Grid -------------------------------------------------------------
    x_all      = linspace(0, L, Nx + 2);   % includes boundary nodes
    x_interior = x_all(2:end-1);           % interior nodes only (row vector)

    % ---- Operators + initial condition ------------------------------------
    A  = build_laplacian(Nx, dx, alpha);   % sparse Nx x Nx matrix
    U0 = sin(pi * x_interior / L)';        % column vector (Nx x 1)

    % ---- Run solvers ------------------------------------------------------
    [U_euler, ~] = euler_solver(A, U0, dt, T);
    [U_rk4,   ~] = rk4_solver (A, U0, dt, T);

    % ---- Exact solution at T ---------------------------------------------
    % exact_solution returns a row vector; transpose to column
    U_exact = exact_solution(x_interior, T, L, alpha)';

    % ---- Errors -----------------------------------------------------------
    err_euler_L2   = norm(U_euler - U_exact, 2)   / sqrt(Nx);
    err_euler_Linf = norm(U_euler - U_exact, inf);
    err_rk4_L2     = norm(U_rk4  - U_exact, 2)   / sqrt(Nx);
    err_rk4_Linf   = norm(U_rk4  - U_exact, inf);

    fprintf('\n=== simulate_heat_1d ===\n');
    fprintf('Parameters: L=%.1f, alpha=%.1f, Nx=%d, dx=%.4f, dt=%.2e, T=%.3f\n', ...
            L, alpha, Nx, dx, dt, T);
    fprintf('CFL limit for Euler: dt_max = %.4e  (used dt = %.2e)  [safe: dt < CFL]\n', ...
            dx^2 / (2*alpha), dt);
    fprintf('\n  Method |  L2 error  | Linf error\n');
    fprintf('  -------|------------|------------\n');
    fprintf('  Euler  | %10.3e | %10.3e\n', err_euler_L2, err_euler_Linf);
    fprintf('  RK4    | %10.3e | %10.3e\n', err_rk4_L2,   err_rk4_Linf);

    % ---- Plot comparison --------------------------------------------------
    ts  = utils_timestamp();
    fig = figure('Name', '1D Heat Conduction - Numerical vs Exact', 'Visible', 'off');

    plot(x_interior, U_exact,  '--k', 'LineWidth', 2.0, 'DisplayName', 'Exact'); hold on;
    plot(x_interior, U_euler,  '-r',  'LineWidth', 1.5, 'DisplayName', ...
         sprintf('Euler  (L2=%.2e)', err_euler_L2));
    plot(x_interior, U_rk4,    '-b',  'LineWidth', 1.5, 'DisplayName', ...
         sprintf('RK4    (L2=%.2e)', err_rk4_L2));
    hold off; grid on;

    xlabel('x');
    ylabel('Temperature u(x, T)');
    legend('Location', 'best');
    title(sprintf('1D Heat Conduction at T=%.3f  (Nx=%d, \\Deltat=%.1e)', T, Nx, dt));

    out = fullfile(results_dir, ['solution_comparison_' ts '.png']);
    saveas(fig, out);
    close(fig);
    fprintf('\nSaved plot: %s\n', out);
end
