function s = utils_timestamp()
%UTILS_TIMESTAMP Returns a filesystem-friendly timestamp string.
%
%   s = utils_timestamp()
%
% Output:
%   s : string in format 'yyyymmdd_HHMMSS', safe for filenames
%
% Uses datetime (preferred over deprecated datestr in newer MATLAB).

    s = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
end
